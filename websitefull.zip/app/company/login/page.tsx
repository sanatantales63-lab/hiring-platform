"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { Briefcase, Loader2, Mail, Lock, Eye, EyeOff, ArrowLeft, Building2, ShieldCheck } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import Link from "next/link";

// Master UI Components
import Card from "@/app/components/ui/Card";
import Button from "@/app/components/ui/Button";

export default function CompanyLogin() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const fetchLegalProof = async () => {
    let ip = "Unknown IP";
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      ip = data.ip;
    } catch (err) {
      console.warn("Could not fetch IP", err);
    }
    return {
      consent_timestamp: new Date().toISOString(),
      consent_ip: ip,
      consent_browser: typeof navigator !== 'undefined' ? navigator.userAgent : "Unknown Browser",
      agreed_to_terms: true
    };
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Strict Consent Check ONLY for Sign Up
    if (isSignUp && !agreedToTerms) {
        return alert("🛑 Legal Requirement: Please read and tick the Terms & Conditions box to proceed.");
    }

    setLoading(true);

    if (isSignUp) {
      const blockedDomains = ["@tempmail.com", "@yopmail.com", "@10minutemail.com", "@guerrillamail.com"];
      const isFakeEmail = blockedDomains.some(domain => email.toLowerCase().endsWith(domain));
      
      if (isFakeEmail || email.toLowerCase().endsWith(".xyz")) {
        setLoading(false);
        return alert("Temporary or disposable emails are not allowed for recruiters.");
      }
    }

    try {
      let authUserId = null;

      if (isSignUp) {
        const { data: authData, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/company/auth/callback`,
          }
        });
        if (error) throw error;
        
        authUserId = authData?.user?.id;

        // Auto-create company row with Legal Proof
        if (authUserId) {
            const legalData = await fetchLegalProof();
            await supabase.from('companies').upsert({
                id: authUserId,
                email: email,
                name: "New Company", 
                status: "pending",
                ...legalData
            });
        }

        alert("Success! Please check your email for the verification link.");
      } else {
        const { error, data } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        
        if (data?.session) {
           authUserId = data.session.user.id;

           const { data: studentData } = await supabase.from('profiles').select('id').eq('id', authUserId).maybeSingle();
           
           if (studentData) {
               await supabase.auth.signOut(); 
               return alert("🛑 Access Denied: This email is registered as a Candidate. Please use the Candidate Portal to login.");
           }

           console.log("Company Login Successful! Redirecting to dashboard...");
           window.location.href = '/company/dashboard';
        } else {
           alert("Login successful, but session not found. Please try again.");
        }
      }
    } catch (error: any) {
      alert("Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-900 flex items-center justify-center p-4 sm:p-6 relative font-sans text-white">
      
      {/* Background Glows */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none" />

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md relative z-10">
        
        {/* Back link */}
        <Link href="/" className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-200/80 hover:text-white mb-6 transition-colors">
          <ArrowLeft size={14} /> Back to Resourcemania Home
        </Link>

        <Card className="bg-white/95 backdrop-blur-2xl border border-white/20 rounded-3xl shadow-2xl p-7 sm:p-9 text-[var(--foreground)]">
          
          {/* Header Icon */}
          <div className="flex justify-center mb-5">
            <div className="bg-gradient-to-br from-amber-500 to-amber-600 p-3.5 rounded-2xl text-white shadow-soft">
               <Building2 className="w-8 h-8 stroke-[2.2]" />
            </div>
          </div>
          
          <h2 className="text-2xl font-black font-display text-center text-[var(--foreground)] tracking-tight">
            Employer Portal
          </h2>
          <p className="text-[var(--muted-foreground)] text-xs font-medium text-center mt-1 mb-6">
            {isSignUp ? "Create a recruiter account to access pre-vetted talent." : "Hire top verified talent with proctored score reports."}
          </p>

          <form onSubmit={handleEmailAuth} className="space-y-4 mb-6">
            <div>
              <label className="text-[11px] font-bold text-[var(--foreground)] uppercase tracking-wider block mb-1.5">Company Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 text-[var(--muted-foreground)]" size={17} />
                <input 
                  type="email" required placeholder="recruiter@company.com" 
                  value={email} onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-[var(--border)] rounded-xl py-3 pl-10 pr-4 text-sm text-[var(--foreground)] placeholder:text-[var(--muted-foreground)]/60 focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/15 outline-none transition-all bg-white"
                />
              </div>
            </div>
            
            <div>
              <label className="text-[11px] font-bold text-[var(--foreground)] uppercase tracking-wider block mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 text-[var(--muted-foreground)]" size={17} />
                <input 
                  type={showPassword ? "text" : "password"} 
                  required placeholder="Min 6 characters" minLength={6}
                  value={password} onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-[var(--border)] rounded-xl py-3 pl-10 pr-11 text-sm text-[var(--foreground)] placeholder:text-[var(--muted-foreground)]/60 focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/15 outline-none transition-all bg-white"
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors"
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              {!isSignUp && (
                <div className="flex justify-end w-full mt-2">
                   <Link href="/forgot-password" className="text-xs text-[var(--primary)] font-bold hover:underline">
                    Forgot Password?
                   </Link>
                </div>
              )}
            </div>

            {/* SMART CONDITIONAL CONSENT */}
            {isSignUp ? (
              <div className="flex items-start gap-3 mt-4 bg-[var(--surface)] border border-[var(--border)] rounded-xl p-3.5">
                 <input 
                    type="checkbox" 
                    id="terms" 
                    checked={agreedToTerms} 
                    onChange={(e) => setAgreedToTerms(e.target.checked)} 
                    className="mt-0.5 w-4 h-4 rounded border-[var(--border)] text-[var(--primary)] focus:ring-[var(--primary)] cursor-pointer"
                 />
                 <label htmlFor="terms" className="text-[11px] text-[var(--muted-foreground)] font-medium leading-relaxed cursor-pointer select-none">
                    I agree to be legally bound by Resourcemania&apos;s <Link href="/terms-of-service" className="text-[var(--primary)] font-bold hover:underline" target="_blank">Terms & Conditions</Link>, and authorize secure access logging.
                 </label>
              </div>
            ) : (
              <div className="mt-3 text-center">
                 <p className="text-[11px] text-[var(--muted-foreground)] font-medium">
                    By logging in, you agree to our <Link href="/terms-of-service" className="text-[var(--primary)] font-bold hover:underline" target="_blank">Terms & Conditions</Link>.
                 </p>
              </div>
            )}

            <Button 
               type="submit" 
               disabled={loading} 
               variant="primary"
               className="w-full mt-3 py-3.5 text-sm font-bold shadow-soft rounded-xl bg-slate-900 text-white hover:bg-slate-800"
            >
              {loading ? <><Loader2 className="animate-spin" size={18}/> Processing...</> : (isSignUp ? "Create Recruiter Account" : "Sign In to Employer Portal")}
            </Button>
          </form>

          <div className="text-center text-xs font-semibold text-[var(--muted-foreground)] pt-3 border-t border-[var(--border)]">
            {isSignUp ? "Already have an account?" : "Don't have an account?"} 
            <button onClick={() => { setIsSignUp(!isSignUp); setAgreedToTerms(false); }} className="text-[var(--primary)] font-extrabold ml-1.5 hover:underline transition-colors">
              {isSignUp ? "Sign In here" : "Sign Up now"}
            </button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}